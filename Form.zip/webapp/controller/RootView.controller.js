sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("Form.Form.controller.RootView", {
		onInit: function () {

		}
	});
});
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("Form.Form.controller.FormView", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf Form.Form.view.FormView
		 */
		onInit: function () {

		},
		onPressOpenRejectBtn:function(){
				if (!this._onOpenRejectDialog) {
				if (!this._onOpenRejectDialog) {
					this._onOpenRejectDialog = sap.ui.xmlfragment("Form.Form.fragment.ResonFragment", this);
					this.getView().addDependent(this._onOpenRejectDialog);
				}
			}
			this._onOpenRejectDialog.open();
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf Form.Form.view.FormView
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf Form.Form.view.FormView
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf Form.Form.view.FormView
		 */
		//	onExit: function() {
		//
		//	}

	});

});